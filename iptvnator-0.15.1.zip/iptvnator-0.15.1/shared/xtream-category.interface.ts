export interface XtreamCategory {
    category_id: string;
    category_name: string;
    parent_id: number;
}
