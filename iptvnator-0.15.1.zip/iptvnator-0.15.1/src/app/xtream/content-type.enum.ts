export enum ContentType {
    VODS = 'vod',
    SERIES = 'series',
    ITV = 'itv',
    FAVORITES = 'favorites',
}
